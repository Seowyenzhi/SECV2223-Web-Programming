<?php
$conn = new mysqli("sql302.infinityfree.com", "if0_39040743", "SHINee2003", "if0_39040743_campus_lostfound");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);

$stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

echo '<!DOCTYPE html>
<html>
<head>
    <title>Password Reset</title>
    <style>
        body {
            background-color: #e0e0e0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            font-family: Arial, sans-serif;
        }
        .message-box {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            text-align: center;
        }
        a {
            color: #2c3e50;
            text-decoration: none;
            font-weight: bold;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="message-box">';

if ($stmt->num_rows > 0) {
    $token = bin2hex(random_bytes(16));
    $update = $conn->prepare("UPDATE users SET reset_token=? WHERE email=?");
    $update->bind_param("ss", $token, $email);
    $update->execute();

    echo "Reset link:<br><a href='reset.php?token=$token'>Click here to reset your password</a>";
} else {
    echo "Email not found.";
}

echo '</div>
</body>
</html>';

$stmt->close();
$conn->close();
?>
