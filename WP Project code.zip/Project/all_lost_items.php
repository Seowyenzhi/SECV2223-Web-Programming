<?php
$conn = new mysqli("sql302.infinityfree.com", "if0_39040743", "SHINee2003", "if0_39040743_campus_lostfound");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$result = $conn->query("SELECT * FROM lost_items ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>All Lost Items</title>
  <link rel="stylesheet" href="css/bstyle.css" />
</head>
<body>

  <!-- HEADER -->
  <header>
    <div class="header-content">
      <h1><a href="home.html">Lost & Found</a></h1>
      <nav>
        <a href="admin-lock.php">Admin</a>
        <a href="register.html">Register</a>
        <a href="login.html">Login</a>
      </nav>
    </div>
  </header>

  <!-- PAGE CONTENT WITH SIDEBAR -->
  <div class="page-wrapper">
    <!-- SIDEBAR -->
    <aside class="sidebar">
      <ul>
        <li><a href="home.html">Home</a></li>
        <li><a href="report_lost.html">Report Lost</a></li>
        <li><a href="view_lost.php">View My Lost</a></li>
        <li><a href="report_found.html">Report Found</a></li>
        <li><a href="view_found.php">View My Found</a></li>
        <li><a href="all_lost_items.php">All Lost Items</a></li>
        <li><a href="all_found_items.php">All Found Items</a></li>
        <li><a href="searchclaim.html">Search & Claim</a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul>
    </aside>

    <!-- MAIN CONTENT -->
    <main class="main-content">
      <div class="container">
        <h2>All Reported Lost Items</h2>
        <table border="1" cellpadding="10" cellspacing="0">
          <tr>
            <th>Name</th>
            <th>Description</th>
            <th>Date Lost</th>
            <th>Time Lost</th>
            <th>Location</th>
            <th>Image</th>
          </tr>

          <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
              <td><?= htmlspecialchars($row['name']) ?></td>
              <td><?= htmlspecialchars($row['description']) ?></td>
              <td><?= $row['date_lost'] ?></td>
              <td><?= $row['time_lost'] ?></td>
              <td><?= htmlspecialchars($row['location']) ?></td>
              <td>
                <?php if (!empty($row['image'])): ?>
                  <img src="uploads/<?= $row['image'] ?>" alt="Item Image" width="80" />
                <?php else: ?>
                  No image
                <?php endif; ?>
              </td>
            </tr>
          <?php endwhile; ?>
        </table>
      </div>
    </main>
  </div>

  <footer>
    &copy; 2025 Lost & Found — All rights reserved.
  </footer>

</body>
</html>
