CREATE TABLE lost_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  description TEXT,
  date_lost DATE,
  time_lost TIME,
  location VARCHAR(100),
  image VARCHAR(255),
  reported_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
