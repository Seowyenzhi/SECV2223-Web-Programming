<?php
header('Content-Type: application/json');

ini_set('display_errors', 1);
error_reporting(E_ALL);

$conn = new mysqli("sql302.infinityfree.com", "if0_39040743", "SHINee2003", "if0_39040743_campus_lostfound");

if ($conn->connect_error) {
  echo json_encode(["error" => "Connection failed"]);
  exit;
}

$sql = "SELECT name, description, date_found, time_found, location, image FROM found_items";
$result = $conn->query($sql);

if (!$result) {
  echo json_encode(["error" => $conn->error]);
  exit;
}

$data = [];
while ($row = $result->fetch_assoc()) {
  $data[] = $row;
}

echo json_encode($data);
?>
