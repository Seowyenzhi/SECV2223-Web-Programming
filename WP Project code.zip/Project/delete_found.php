<?php
$conn = new mysqli("sql302.infinityfree.com", "if0_39040743", "SHINee2003", "if0_39040743_campus_lostfound");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = $_GET['id'];
$stmt = $conn->prepare("DELETE FROM found_items WHERE id = ?");
$stmt->bind_param("i", $id);

$deleted = false;
if ($stmt->execute()) {
    $deleted = true;
}
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Delete Found Item</title>
  <link rel="stylesheet" href="css/bstyle.css" />
</head>
<body>
  <header>
    <div class="header-content">
      <h1><a href="home.html">Lost & Found</a></h1>
      <nav>
        <a href="admin-lock.php">Admin</a>
        <a href="register.html">Register</a>
        <a href="login.html">Login</a>
      </nav>
    </div>
  </header>

  <div class="page-wrapper">
    <aside class="sidebar">
      <ul>
        <li><a href="home.html">Home</a></li>
        <li><a href="report_found.html">Report Found</a></li>
        <li><a href="view_found.php">View My Found</a></li>
        <li><a href="all_found_items.php">All Found Items</a></li>
      </ul>
    </aside>

    <main class="main-content">
      <div class="container">
        <h2>Delete Status</h2>
        <?php if ($deleted): ?>
          <p class="success">✅ Found item deleted successfully.</p>
        <?php else: ?>
          <p class="error">❌ Failed to delete item. Please try again.</p>
        <?php endif; ?>
        <a href="view_found.php" class="btn">← Back to My Found Items</a>
      </div>
    </main>
  </div>

  <footer>
    &copy; 2025 Lost & Found — All rights reserved.
  </footer>
</body>
</html>
