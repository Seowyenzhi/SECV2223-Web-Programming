<?php
$conn = new mysqli("sql302.infinityfree.com", "if0_39040743", "SHINee2003", "if0_39040743_campus_lostfound");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = $_POST['id'];
$name = htmlspecialchars($_POST['name']);
$description = htmlspecialchars($_POST['description']);
$date = $_POST['date_found'];
$time = $_POST['time_found'];
$location = htmlspecialchars($_POST['location']);

$imageName = "";
if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
    $originalName = basename($_FILES['image']['name']);
    $extension = pathinfo($originalName, PATHINFO_EXTENSION);
    $imageName = uniqid("img_", true) . "." . $extension;
    move_uploaded_file($_FILES['image']['tmp_name'], "uploads/" . $imageName);

    $sql = "UPDATE found_items SET name=?, description=?, date_found=?, time_found=?, location=?, image=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssi", $name, $description, $date, $time, $location, $imageName, $id);
} else {
    $sql = "UPDATE found_items SET name=?, description=?, date_found=?, time_found=?, location=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssi", $name, $description, $date, $time, $location, $id);
}

$success = false;
if ($stmt->execute()) {
    $success = true;
}
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Update Found Item</title>
  <link rel="stylesheet" href="css/bstyle.css" />
</head>
<body>
  <header>
    <div class="header-content">
      <h1><a href="home.html">Lost & Found</a></h1>
      <nav>
        <a href="admin-lock.php">Admin</a>
        <a href="register.html">Register</a>
        <a href="login.html">Login</a>
      </nav>
    </div>
  </header>

  <div class="page-wrapper">
    <aside class="sidebar">
      <ul>
        <li><a href="home.html">Home</a></li>
        <li><a href="report_found.html">Report Found</a></li>
        <li><a href="view_found.php">View My Found</a></li>
        <li><a href="all_found_items.php">All Found Items</a></li>
      </ul>
    </aside>

    <main class="main-content">
      <div class="container">
        <h2>Update Status</h2>
        <?php if ($success): ?>
          <p class="success">✅ Found item updated successfully.</p>
        <?php else: ?>
          <p class="error">❌ Failed to update item. Please try again.</p>
        <?php endif; ?>
        <a href="view_found.php" class="btn">← Back to My Found Items</a>
      </div>
    </main>
  </div>

  <footer>
    &copy; 2025 Lost & Found — All rights reserved.
  </footer>
</body>
</html>
