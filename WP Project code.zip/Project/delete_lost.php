<?php
$conn = new mysqli("sql302.infinityfree.com", "if0_39040743", "SHINee2003", "if0_39040743_campus_lostfound");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_GET['id'])) {
    die("Missing item ID");
}

$id = $_GET['id'];

// First, get item details
$stmt = $conn->prepare("SELECT * FROM lost_items WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    die("Item not found");
}
$item = $result->fetch_assoc();
$stmt->close();

// Now delete
$stmt = $conn->prepare("DELETE FROM lost_items WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Delete Lost Item</title>
  <link rel="stylesheet" href="css/bstyle.css" />
</head>
<body>

<header>
  <div class="header-content">
    <h1><a href="home.html">Lost & Found</a></h1>
  </div>
</header>

<div class="page-wrapper">
  <aside class="sidebar">
    <ul>
      <li><a href="home.html">Home</a></li>
      <li><a href="report_lost.html">Report Lost</a></li>
      <li><a href="view_lost.php">View My Lost</a></li>
      <li><a href="report_found.html">Report Found</a></li>
      <li><a href="view_found.php">View My Found</a></li>
      <li><a href="all_lost_items.php">All Lost Items</a></li>
      <li><a href="all_found_items.php">All Found Items</a></li>
      <li><a href="searchclaim.html">Search & Claim</a></li>
    </ul>
  </aside>

  <main class="main-content">
    <div class="container">
      <h2>Deleted Successfully</h2>
      <p>The lost item <strong><?= htmlspecialchars($item['description']) ?></strong> has been deleted.</p>
      <a href="view_lost.php" class="btn">Back to My Lost Items</a>
    </div>
  </main>
</div>

<footer>
  &copy; 2025 Lost & Found — All rights reserved.
</footer>

</body>
</html>
