<?php
session_start();
$conn = new mysqli("sql302.infinityfree.com", "if0_39040743", "SHINee2003", "if0_39040743_campus_lostfound");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$email = trim($_POST['email']);
$password = trim($_POST['password']);

$stmt = $conn->prepare("SELECT id, password, role FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if ($user && password_verify($password, $user['password'])) {
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['role'] = $user['role'];

    $log_stmt = $conn->prepare("INSERT INTO login_logs (user_id, email) VALUES (?, ?)");
    $log_stmt->bind_param("is", $user['id'], $email);
    $log_stmt->execute();
    $log_stmt->close();

    header("Location: dashboard.php");
    exit();
} else {
    echo "Invalid email or password. <a href='login.html'>Try again</a>";
}

$stmt->close();
$conn->close();
?>
