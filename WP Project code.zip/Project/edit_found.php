<?php
$conn = new mysqli("sql302.infinityfree.com", "if0_39040743", "SHINee2003", "if0_39040743_campus_lostfound");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM found_items WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$item = $result->fetch_assoc();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Edit Found Item</title>
  <link rel="stylesheet" href="css/bstyle.css" />
</head>
<body>
  <header>
    <div class="header-content">
      <h1><a href="home.html">Lost & Found</a></h1>
      <nav>
        <a href="admin-lock.php">Admin</a>
        <a href="register.html">Register</a>
        <a href="login.html">Login</a>
      </nav>
    </div>
  </header>

  <div class="page-wrapper">
    <aside class="sidebar">
      <ul>
        <li><a href="home.html">Home</a></li>
        <li><a href="report_found.html">Report Found</a></li>
        <li><a href="view_found.php">View My Found</a></li>
        <li><a href="all_found_items.php">All Found Items</a></li>
      </ul>
    </aside>

    <main class="main-content">
      <div class="container">
        <h2>Edit Found Item</h2>
        <form action="update_found.php" method="POST" enctype="multipart/form-data">
          <input type="hidden" name="id" value="<?= $item['id'] ?>" />

          <label>Your Name:</label>
          <input type="text" name="name" value="<?= htmlspecialchars($item['name']) ?>" required />

          <label>Description:</label>
          <textarea name="description" required><?= htmlspecialchars($item['description']) ?></textarea>

          <label>Date Found:</label>
          <input type="date" name="date_found" value="<?= $item['date_found'] ?>" required />

          <label>Time Found:</label>
          <input type="time" name="time_found" value="<?= $item['time_found'] ?>" required />

          <label>Location:</label>
          <input type="text" name="location" value="<?= htmlspecialchars($item['location']) ?>" required />

          <label>Update Image (optional):</label>
          <input type="file" name="image" accept="image/*" />

          <input type="submit" value="Update Found Report" class="btn" />
        </form>
      </div>
    </main>
  </div>

  <footer>
    &copy; 2025 Lost & Found — All rights reserved.
  </footer>
</body>
</html>
