<?php
// Connect to database
$conn = new mysqli("sql302.infinityfree.com", "if0_39040743", "SHINee2003", "if0_39040743_campus_lostfound");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get item ID
if (!isset($_GET['id'])) {
    die("Missing item ID");
}

$id = $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM lost_items WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Item not found");
}

$row = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Edit Lost Item</title>
  <link rel="stylesheet" href="css/bstyle.css" />
</head>
<body>

<header>
  <div class="header-content">
    <h1><a href="home.html">Lost & Found</a></h1>
    <nav>
      <a href="admin-lock.php">Admin</a>
      <a href="register.html">Register</a>
      <a href="login.html">Login</a>
    </nav>
  </div>
</header>

<div class="page-wrapper">

  <!-- SIDEBAR -->
  <aside class="sidebar">
    <ul>
      <li><a href="home.html">Home</a></li>
      <li><a href="report_lost.html">Report Lost</a></li>
      <li><a href="view_lost.php">View My Lost</a></li>
      <li><a href="report_found.html">Report Found</a></li>
      <li><a href="view_found.php">View My Found</a></li>
      <li><a href="all_lost_items.php">All Lost Items</a></li>
      <li><a href="all_found_items.php">All Found Items</a></li>
      <li><a href="searchclaim.html">Search & Claim</a></li>
    </ul>
  </aside>

  <!-- MAIN -->
  <main class="main-content">
    <div class="container">
      <h2>Edit Lost Report</h2>
      <form action="update_lost.php" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?= $row['id'] ?>" />

        <label for="name">Your Name:</label>
        <input type="text" id="name" name="name" value="<?= htmlspecialchars($row['name']) ?>" required />

        <label for="description">Item Description:</label>
        <textarea id="description" name="description" required><?= htmlspecialchars($row['description']) ?></textarea>

        <label for="date_lost">Date Lost:</label>
        <input type="date" id="date_lost" name="date_lost" value="<?= $row['date_lost'] ?>" required />

        <label for="time_lost">Time Lost:</label>
        <input type="time" id="time_lost" name="time_lost" value="<?= $row['time_lost'] ?>" required />

        <label for="location">Location Lost:</label>
        <input type="text" id="location" name="location" value="<?= htmlspecialchars($row['location']) ?>" required />

        <label for="image">Replace Image (optional):</label>
        <input type="file" id="image" name="image" accept="image/*" />

        <input type="hidden" name="existing_image" value="<?= $row['image'] ?>" />

        <input type="submit" value="Update Lost Report" class="btn" />
      </form>
    </div>
  </main>
</div>

<footer>
  &copy; 2025 Lost & Found — All rights reserved.
</footer>
</body>
</html>
