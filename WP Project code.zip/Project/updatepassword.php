<?php
$conn = new mysqli("sql302.infinityfree.com", "if0_39040743", "SHINee2003", "if0_39040743_campus_lostfound");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$token = $_POST['token'];
$new_password = trim($_POST['new_password']);
$hashed = password_hash($new_password, PASSWORD_DEFAULT);

$stmt = $conn->prepare("UPDATE users SET password=?, reset_token=NULL WHERE reset_token=?");
$stmt->bind_param("ss", $hashed, $token);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    echo "Password updated successfully! <a href='login.html'>Login</a>";
} else {
    echo "Invalid or expired reset link.";
}

$stmt->close();
$conn->close();
?>
