<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Dashboard</title>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background: #e1e1de;
      color: #333;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }

    /* Header */
    header {
      background: #3f4245;
      color: white;
    }

    .header-content {
      max-width: 1100px;
      margin: 0 auto;
      padding: 1.5rem 2rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    header h1 {
      margin: 0;
      font-size: 1.8rem;
    }

    header h1 a {
      color: white;
      text-decoration: none;
    }

    nav a {
      color: white;
      margin-left: 2rem;
      text-decoration: none;
      font-weight: bold;
    }

    nav a:hover {
      text-decoration: underline;
    }

    /* Main content */
    .dashboard-wrapper {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 4rem 2rem;
      text-align: center;
    }

    .dashboard-wrapper h2 {
      margin-bottom: 0.5rem;
      color: #3f4245;
    }

    .dashboard-buttons {
      margin-top: 2rem;
      display: flex;
      flex-direction: column;
      gap: 20px;
    }

    .dashboard-buttons a {
      text-decoration: none;
      background-color: #3f4245;
      color: white;
      padding: 14px 28px;
      border-radius: 8px;
      font-size: 18px;
      font-weight: bold;
      width: 220px;
      transition: background-color 0.3s ease;
    }

    .dashboard-buttons a:hover {
      background-color: #5b5f63;
    }

    footer {
      background: #3f4245;
      color: white;
      text-align: center;
      padding: 2rem 1rem;
      font-weight: bold;
    }
  </style>
</head>
<body>

  <!-- HEADER -->
  <header>
    <div class="header-content">
      <h1><a href="home.html">Lost & Found</a></h1>
      <nav>
        <span>Logged in as <strong><?php echo htmlspecialchars($_SESSION['role']); ?></strong></span>
        <a href="home.html">Logout</a>
      </nav>
    </div>
  </header>

  <!-- DASHBOARD CONTENT -->
  <main class="dashboard-wrapper">
    <h2>Welcome to your dashboard!</h2>
    <p>You are logged in as a <strong><?php echo htmlspecialchars($_SESSION['role']); ?></strong>.</p>

    <div class="dashboard-buttons">
      <a href="report_lost.html">Report Lost Item</a>
      <a href="report_found.html">Report Found Item</a>
      <a href="searchclaim.html">Search & Claim</a>
    </div>
  </main>

  <!-- FOOTER -->
  <footer>
    &copy; 2025 Lost & Found — All rights reserved.
  </footer>

</body>
</html>


