<?php
$conn = new mysqli("sql302.infinityfree.com", "if0_39040743", "SHINee2003", "if0_39040743_campus_lostfound");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id         = $_POST['id'];
$name       = htmlspecialchars($_POST['name']);
$desc       = htmlspecialchars($_POST['description']);
$date       = $_POST['date_lost'];
$time       = $_POST['time_lost'];
$location   = htmlspecialchars($_POST['location']);

$imageName = $_POST['existing_image'] ?? "";
if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
    $originalName = basename($_FILES['image']['name']);
    $ext = pathinfo($originalName, PATHINFO_EXTENSION);
    $imageName = uniqid("img_", true) . "." . $ext;
    $targetPath = "uploads/" . $imageName;
    move_uploaded_file($_FILES['image']['tmp_name'], $targetPath);
}

$sql = "UPDATE lost_items SET name=?, description=?, date_lost=?, time_lost=?, location=?, image=? WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssssi", $name, $desc, $date, $time, $location, $imageName, $id);

$success = false;
if ($stmt->execute()) {
    $success = true;
} else {
    $error = $conn->error;
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Update Lost Item</title>
  <link rel="stylesheet" href="css/bstyle.css" />
</head>
<body>

<header>
  <div class="header-content">
    <h1><a href="home.html">Lost & Found</a></h1>
    <nav>
      <a href="admin-lock.php">Admin</a>
      <a href="register.html">Register</a>
      <a href="login.html">Login</a>
    </nav>
  </div>
</header>

<div class="page-wrapper">
  <aside class="sidebar">
    <ul>
      <li><a href="home.html">Home</a></li>
      <li><a href="report_lost.html">Report Lost</a></li>
      <li><a href="view_lost.php">View My Lost</a></li>
      <li><a href="report_found.html">Report Found</a></li>
      <li><a href="view_found.php">View My Found</a></li>
      <li><a href="all_lost_items.php">All Lost Items</a></li>
      <li><a href="all_found_items.php">All Found Items</a></li>
      <li><a href="searchclaim.html">Search & Claim</a></li>
    </ul>
  </aside>

  <main class="main-content">
    <div class="container">
      <h2>Update Lost Report</h2>
      <?php if ($success): ?>
        <p><strong>✅ Lost item updated successfully.</strong></p>
      <?php else: ?>
        <p><strong style="color:red;">❌ Error:</strong> <?= $error ?></p>
      <?php endif; ?>
      <a href="view_lost.php" class="btn">Back to My Lost Items</a>
    </div>
  </main>
</div>

<footer>
  &copy; 2025 Lost & Found — All rights reserved.
</footer>

</body>
</html>
