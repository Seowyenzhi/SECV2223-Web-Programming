<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

$conn = new mysqli("sql302.infinityfree.com", "if0_39040743", "SHINee2003", "if0_39040743_campus_lostfound");

if ($conn->connect_error) {
  echo json_encode(["error" => "Connection failed"]);
  exit;
}

$sql = "SELECT name, description, date_lost, time_lost, location FROM lost_items";
$result = $conn->query($sql);

if (!$result) {
  echo json_encode(["error" => $conn->error]);
  exit;
}

$data = [];
while ($row = $result->fetch_assoc()) {
  $data[] = $row;
}

echo json_encode($data);
?>
