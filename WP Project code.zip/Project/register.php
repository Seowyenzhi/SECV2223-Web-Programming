<?php
$conn = new mysqli("sql302.infinityfree.com", "if0_39040743", "SHINee2003", "if0_39040743_campus_lostfound");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$name = trim($_POST['name']);
$email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
$password = trim($_POST['password']);

// Validate email
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die("Invalid email format.");
}

// Check if email already exists
$check = $conn->prepare("SELECT id FROM users WHERE email = ?");
$check->bind_param("s", $email);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
    die("Email is already registered.");
}
$check->close();

// Hash password
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

// Insert new user
$stmt = $conn->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, 'user')");
$stmt->bind_param("sss", $name, $email, $hashedPassword);

if ($stmt->execute()) {
    echo "
    <!DOCTYPE html>
    <html>
    <head>
        <title>Registration Success</title>
        <style>
            body {
                margin: 0;
                padding: 0;
                background-color: #e0e0e0;
                font-family: Arial, sans-serif;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                text-align: center;
            }
            .message-box {
                background: white;
                padding: 30px 40px;
                border-radius: 10px;
                box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            }
            .message-box a {
                display: inline-block;
                margin-top: 15px;
                padding: 10px 20px;
                background-color: #bfc8d0;
                color: black;
                text-decoration: none;
                border-radius: 6px;
                transition: background-color 0.3s;
            }
            .message-box a:hover {
                background-color: #aeb7c0;
            }
        </style>
    </head>
    <body>
        <div class='message-box'>
            <h2>Register Successfully!</h2>
            <a href='home.html'>Back To Home</a>
        </div>
    </body>
    </html>
    ";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
