<?php
$conn = new mysqli("sql302.infinityfree.com", "if0_39040743", "SHINee2003", "if0_39040743_campus_lostfound");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$nameFilter = "";
$results = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['search_name'])) {
    $nameFilter = htmlspecialchars($_POST['search_name']);
    $stmt = $conn->prepare("SELECT * FROM found_items WHERE name = ? ORDER BY id DESC");
    $stmt->bind_param("s", $nameFilter);
    $stmt->execute();
    $results = $stmt->get_result();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>View My Found Items</title>
  <link rel="stylesheet" href="css/bstyle.css" />
</head>
<body>
  <!-- Reuse header and sidebar -->
  <header>
    <div class="header-content">
      <h1><a href="home.html">Lost & Found</a></h1>
      <nav>
        <a href="admin-lock.php">Admin</a>
        <a href="register.html">Register</a>
        <a href="login.html">Login</a>
      </nav>
    </div>
  </header>

  <div class="page-wrapper">
    <aside class="sidebar">
      <ul>
        <li><a href="home.html">Home</a></li>
        <li><a href="report_found.html">Report Found</a></li>
        <li><a href="view_found.php">View My Found</a></li>
        <li><a href="report_lost.html">Report Lost</a></li>
        <li><a href="view_lost.php">View My Lost</a></li>
        <li><a href="all_found_items.php">All Found Items</a></li>
        <li><a href="all_lost_items.php">All Lost Items</a></li>
        <li><a href="searchclaim.html">Search & Claim</a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul>
    </aside>

    <main class="main-content">
      <div class="container">
        <h2>View My Found Item Reports</h2>

        <form method="POST" style="margin-bottom: 20px;">
          <label for="search_name">Enter your name to view your submissions:</label>
          <input type="text" id="search_name" name="search_name" value="<?= htmlspecialchars($nameFilter) ?>" required>
          <button type="submit" class="btn">Search</button>
        </form>

        <?php if ($results && $results->num_rows > 0): ?>
          <table border="1" cellpadding="8" cellspacing="0">
            <tr>
              <th>Name</th><th>Description</th><th>Date</th><th>Time</th><th>Location</th><th>Actions</th>
            </tr>
            <?php while ($row = $results->fetch_assoc()): ?>
              <tr>
                <td><?= htmlspecialchars($row['name']) ?></td>
                <td><?= htmlspecialchars($row['description']) ?></td>
                <td><?= $row['date_found'] ?></td>
                <td><?= $row['time_found'] ?></td>
                <td><?= htmlspecialchars($row['location']) ?></td>
                <td>
                  <a href="edit_found.php?id=<?= $row['id'] ?>">Edit</a> |
                  <a href="delete_found.php?id=<?= $row['id'] ?>" onclick="return confirm('Delete this item?')">Delete</a>
                </td>
              </tr>
            <?php endwhile; ?>
          </table>
        <?php elseif ($nameFilter): ?>
          <p>No entries found for <strong><?= $nameFilter ?></strong>.</p>
        <?php endif; ?>
      </div>
    </main>
  </div>

  <footer>
    &copy; 2025 Lost & Found — All rights reserved.
  </footer>
</body>
</html>
