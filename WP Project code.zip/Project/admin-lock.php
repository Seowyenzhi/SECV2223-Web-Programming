<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $password = $_POST['password'];

  if ($password === 'admin') {
    $_SESSION['admin_unlocked'] = true;
    header("Location: admin.php");
    exit();
  } else {
    $error = "Incorrect password.";
  }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Admin Access</title>
  <link rel="stylesheet" href="bstyle.css">
  <style>
    body { text-align: center; padding: 60px; background: #f5f5f5; }
    input[type=password], input[type=submit] {
      padding: 10px;
      font-size: 18px;
      margin-top: 10px;
    }
  </style>
</head>
<body>
  <h2>Admin Access Required</h2>
  <?php if (!empty($error)) echo "<p style='color:red;'>$error</p>"; ?>
  <form method="POST">
    <input type="password" name="password" placeholder="Enter admin password" required><br>
    <input type="submit" value="Enter">
  </form>
</body>
</html>
