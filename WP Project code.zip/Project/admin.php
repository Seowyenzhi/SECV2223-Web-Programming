<?php
session_start();
if (!isset($_SESSION['admin_unlocked']) || $_SESSION['admin_unlocked'] !== true) {
  header("Location: admin-lock.php");
  exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Admin Panel - Lost & Found</title>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background: #e1e1de;
      color: #333;
    }

    header {
      background: #3f4245;
      color: white;
    }

    .header-content {
      max-width: 1100px;
      margin: 0 auto;
      padding: 1.5rem 2rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    header h1 {
      margin: 0;
    }

    nav a {
      color: white;
      margin-left: 2rem;
      text-decoration: none;
      font-weight: bold;
    }

    nav a:hover {
      text-decoration: underline;
    }

    .hero {
      background: #f7f7f7;
      padding: 3rem 2rem;
      text-align: center;
    }

    .hero h2 {
      margin: 0 0 1rem 0;
      font-size: 2rem;
      color: #3f4245;
    }

    .hero p {
      margin: 0;
      font-size: 1.1rem;
      color: #3f4245;
    }

    .cards {
      max-width: 1100px;
      margin: 3rem auto;
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 2rem;
    }

    .card {
      background: white;
      border-radius: 10px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      padding: 2rem;
      flex: 1 1 250px;
      max-width: 300px;
      text-align: center;
    }

    .card h3 {
      margin-top: 0;
      color: #3f4245;
    }

    .btn {
      display: inline-block;
      margin-top: 1rem;
      padding: 0.6rem 1.2rem;
      background: #3f4245;
      color: white;
      text-decoration: none;
      border-radius: 5px;
      font-weight: bold;
      cursor: pointer;
    }

    .btn:hover {
      background: #5b5f63;
    }

    #sectionDisplay {
      margin: 3rem auto;
      max-width: 1100px;
      padding: 2rem;
      background: white;
      border-radius: 10px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }

    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 1rem;
    }

    th, td {
      border: 1px solid #ccc;
      padding: 12px;
      text-align: center;
    }

    th {
      background: #f2f2f2;
    }

    footer {
      background: #3f4245;
      color: white;
      text-align: center;
      padding: 2rem 1rem;
      font-weight: bold;
    }
  </style>
</head>
<body>

  <!-- HEADER -->
  <header>
    <div class="header-content">
    <h1>Lost & Found</h1>
      <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="logout.php">Logout</a>
      </nav>
    </div>
  </header>

  <!-- HERO SECTION -->
  <section class="hero">
    <h2>📋 Welcome, admin. </h2>
    <p>Manage user logins and item records for Lost & Found</p>
  </section>

  <!-- CARD BUTTONS -->
  <section class="cards">
    <div class="card">
      <h3>👤 User Logins</h3>
      <p>View all login activities by users.</p>
      <button class="btn" onclick="loadSection('users')">View Users</button>
    </div>
    <div class="card">
      <h3>🔍 Lost Items</h3>
      <p>See all items that have been reported as lost.</p>
      <button class="btn" onclick="loadSection('lost')">View Lost Items</button>
    </div>
    <div class="card">
      <h3>📦 Found Items</h3>
      <p>See all items that have been found and submitted.</p>
      <button class="btn" onclick="loadSection('found')">View Found Items</button>
    </div>
  </section>

  <div id="sectionDisplay"></div>

  <!-- FOOTER -->
  <footer>
    &copy; 2025 Lost & Found — All rights reserved.
  </footer>

  <!-- JAVASCRIPT FETCH -->
  <script>
    function loadSection(type) {
      const endpoints = {
        users: "get_users.php",
        lost: "get_lost_items.php",
        found: "get_found_items.php"
      };

      const section = document.getElementById("sectionDisplay");
      section.innerHTML = "<p>Loading...</p>";

      fetch(endpoints[type])
        .then(res => res.json())
        .then(data => {
          if (!Array.isArray(data) || data.length === 0) {
            section.innerHTML = "<p>No data available.</p>";
            return;
          }

          let html = "<table><thead><tr>";

          if (type === "users") {
            html += "<th>#</th><th>User ID</th><th>Email</th><th>Login Time</th>";
          } else if (type === "lost") {
            html += "<th>#</th><th>Name</th><th>Description</th><th>Date Lost</th><th>Time Lost</th><th>Location</th>";
          } else if (type === "found") {
            html += "<th>#</th><th>Name</th><th>Description</th><th>Date Found</th><th>Time Found</th><th>Location</th>";
          }

          html += "</tr></thead><tbody>";

          data.forEach((item, index) => {
            html += `<tr><td>${index + 1}</td>`;

            if (type === "users") {
              html += `<td>${item.user_id}</td><td>${item.email}</td><td>${item.login_time}</td>`;
            } else if (type === "lost") {
              html += `<td>${item.name}</td><td>${item.description}</td><td>${item.date_lost}</td><td>${item.time_lost}</td><td>${item.location}</td>`;
            } else if (type === "found") {
              html += `<td>${item.name}</td><td>${item.description}</td><td>${item.date_found}</td><td>${item.time_found}</td><td>${item.location}</td>`;
            }

            html += "</tr>";
          });

          html += "</tbody></table>";
          section.innerHTML = html;
        })
        .catch(err => {
          console.error("Error:", err);
          section.innerHTML = "<p>Failed to load data.</p>";
        });
    }
  </script>

</body>
</html>
