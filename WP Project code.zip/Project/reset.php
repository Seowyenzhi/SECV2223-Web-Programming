<?php
// reset.php — show form if token exists
$token = $_GET['token'] ?? '';

if (!$token) {
    die("Invalid or missing token.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Reset Password</title>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background: #e1e1de;
      color: #333;
    }

    /* Header */
    header {
      background: #3f4245;
      color: white;
    }

    .header-content {
      max-width: 1100px;
      margin: 0 auto;
      padding: 1.5rem 2rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    header h1 {
      margin: 0;
      font-size: 1.8rem;
    }

    header h1 a {
      color: white;
      text-decoration: none;
    }

    nav a {
      color: white;
      margin-left: 2rem;
      text-decoration: none;
      font-weight: bold;
    }

    nav a:hover {
      text-decoration: underline;
    }

    /* Form wrapper */
    .form-wrapper {
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 4rem 2rem;
    }

    .reset-container {
      background: #f7f7f7;
      padding: 2rem 3rem;
      border-radius: 10px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
      max-width: 400px;
      width: 100%;
    }

    .reset-container h2 {
      text-align: center;
      margin-bottom: 1.5rem;
      color: #3f4245;
    }

    .reset-container input {
      width: 100%;
      padding: 0.75rem 1rem;
      margin: 0.5rem 0;
      border: 1px solid #ccc;
      border-radius: 5px;
    }

    .reset-container button {
      width: 100%;
      padding: 0.75rem;
      margin-top: 1rem;
      background: #3f4245;
      color: white;
      border: none;
      border-radius: 5px;
      font-weight: bold;
      cursor: pointer;
    }

    .reset-container button:hover {
      background: #5b5f63;
    }

    footer {
      background: #3f4245;
      color: white;
      text-align: center;
      padding: 2rem 1rem;
      font-weight: bold;
    }
  </style>
</head>
<body>

  <!-- HEADER -->
  <header>
    <div class="header-content">
      <h1><a href="home.html">Lost & Found</a></h1>
      <nav>
        <a href="admin-lock.php">Admin</a>
        <a href="register.html">Register</a>
        <a href="login.html">Login</a>
      </nav>
    </div>
  </header>

  <!-- RESET FORM -->
  <main class="form-wrapper">
    <div class="reset-container">
      <h2>Reset Your Password</h2>
      <form action="reset_handler.php" method="POST">
        <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
        <input type="password" name="new_password" placeholder="New Password" required>
        <input type="password" name="confirm_password" placeholder="Confirm Password" required>
        <button type="submit">Update Password</button>
      </form>
    </div>
  </main>

  <!-- FOOTER -->
  <footer>
    &copy; 2025 Lost & Found — All rights reserved.
  </footer>

</body>
</html>
