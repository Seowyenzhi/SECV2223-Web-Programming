<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Connect to database
$conn = new mysqli("sql302.infinityfree.com", "if0_39040743", "SHINee2003", "if0_39040743_campus_lostfound");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get search inputs
$keyword = $_GET['keyword'] ?? '';
$location = $_GET['location'] ?? '';
$date = $_GET['date'] ?? '';

// Escape inputs for SQL
$keyword_sql = $conn->real_escape_string($keyword);
$location_sql = $conn->real_escape_string($location);
$date_sql = $conn->real_escape_string($date);

// Query lost_items
$sql_lost = "SELECT id, name, description, location, image, date_lost AS date_reported, 'lost' AS type 
             FROM lost_items WHERE 1=1";

if (!empty($keyword)) {
    $sql_lost .= " AND (name LIKE '%$keyword_sql%' OR description LIKE '%$keyword_sql%')";
}
if (!empty($location)) {
    $sql_lost .= " AND location LIKE '%$location_sql%'";
}
if (!empty($date)) {
    $sql_lost .= " AND date_lost = '$date_sql'";
}

// Query found_items
$sql_found = "SELECT id, name, description, location, image, date_found AS date_reported, 'found' AS type 
              FROM found_items WHERE 1=1";

if (!empty($keyword)) {
    $sql_found .= " AND (name LIKE '%$keyword_sql%' OR description LIKE '%$keyword_sql%')";
}
if (!empty($location)) {
    $sql_found .= " AND location LIKE '%$location_sql%'";
}
if (!empty($date)) {
    $sql_found .= " AND date_found = '$date_sql'";
}

// Combine queries
$sql = "($sql_lost) UNION ALL ($sql_found) ORDER BY date_reported DESC";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<h3>Search Results:</h3>";
    while ($item = $result->fetch_assoc()) {
        echo "<div class='item'>";
        echo "<h4>" . htmlspecialchars($item['name']) . " (" . htmlspecialchars($item['type']) . ")</h4>";
        echo "<p><strong>Location:</strong> " . htmlspecialchars($item['location']) . "</p>";
        echo "<p><strong>Date:</strong> " . htmlspecialchars($item['date_reported']) . "</p>";
        echo "<p><strong>Description:</strong> " . htmlspecialchars($item['description']) . "</p>";

        // ✅ Safe image display (InfinityFree-friendly)
        $imagePath = "uploads/" . $item['image'];
        if (!empty($item['image']) && file_exists($imagePath)) {
            echo "<img src='" . htmlspecialchars($imagePath) . "' width='200'><br><br>";
        } else {
            echo "<p><em>No image available.</em></p>";
        }

        // ✅ Claim form with source
        echo "<form action='claim.php' method='POST'>";
        echo "<input type='hidden' name='item_id' value='" . $item['id'] . "'>";
        echo "<input type='hidden' name='source' value='" . $item['type'] . "'>";
        echo "<label>Why do you think this item is yours?</label><br>";
        echo "<textarea name='claim_reason' required></textarea><br><br>";
        echo "<button type='submit'>Submit Claim</button>";
        echo "</form><hr></div>";
    }
} else {
    echo "<p>No results found. Try different keywords or filters.</p>";
}

$conn->close();
?>
