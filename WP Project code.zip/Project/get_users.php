<?php
header('Content-Type: application/json');

$conn = new mysqli("sql302.infinityfree.com", "if0_39040743", "SHINee2003", "if0_39040743_campus_lostfound");

if ($conn->connect_error) {
  http_response_code(500);
  echo json_encode(["error" => "Connection failed"]);
  exit();
}

$sql = "SELECT id, user_id, email, login_time FROM login_logs ORDER BY login_time DESC";
$result = $conn->query($sql);

$logs = [];

if ($result && $result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $logs[] = $row;
  }
}

echo json_encode($logs);
$conn->close();
?>
