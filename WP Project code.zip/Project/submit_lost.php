<?php
$conn = new mysqli("sql302.infinityfree.com", "if0_39040743", "SHINee2003", "if0_39040743_campus_lostfound");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$name = htmlspecialchars($_POST['name']);
$description = htmlspecialchars($_POST['description']);
$date = $_POST['date_lost'];
$time = $_POST['time_lost'];
$location = htmlspecialchars($_POST['location']);

$imageName = "";
if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
    $originalName = basename($_FILES['image']['name']);
    $extension = pathinfo($originalName, PATHINFO_EXTENSION);
    $imageName = uniqid("img_", true) . "." . $extension;
    $targetPath = "uploads/" . $imageName;

    if (!move_uploaded_file($_FILES['image']['tmp_name'], $targetPath)) {
        $message = "Image upload failed.";
    }
}

$sql = "INSERT INTO lost_items (name, description, date_lost, time_lost, location, image) VALUES (?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssss", $name, $description, $date, $time, $location, $imageName);

$success = false;
if ($stmt->execute()) {
    $message = "✅ Lost item reported successfully.";
    $success = true;
} else {
    $message = "❌ Error: " . $conn->error;
}
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Lost Item Submission</title>
  <link rel="stylesheet" href="css/bstyle.css" />
</head>
<body>
  <header>
    <div class="header-content">
      <h1><a href="home.html">Lost & Found</a></h1>
      <nav>
        <a href="admin-lock.php">Admin</a>
        <a href="register.html">Register</a>
        <a href="login.html">Login</a>
      </nav>
    </div>
  </header>

  <div class="page-wrapper">
    <aside class="sidebar">
      <ul>
        <li><a href="home.html">Home</a></li>
        <li><a href="report_lost.html">Report Lost</a></li>
        <li><a href="view_lost.php">View My Lost</a></li>
        <li><a href="report_found.html">Report Found</a></li>
        <li><a href="view_found.php">View My Found</a></li>
        <li><a href="all_lost_items.php">All Lost Items</a></li>
        <li><a href="all_found_items.php">All Found Items</a></li>
        <li><a href="searchclaim.html">Search & Claim</a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul>
    </aside>

    <main class="main-content">
      <div class="container">
        <h2>Submission Result</h2>
        <p><?= $message ?></p>
        <?php if ($success): ?>
          <a href="view_lost.php" class="btn">View My Lost Reports</a>
        <?php else: ?>
          <a href="report_lost.html" class="btn">Back to Report</a>
        <?php endif; ?>
      </div>
    </main>
  </div>

  <footer>
    &copy; 2025 Lost & Found — All rights reserved.
  </footer>
</body>
</html>
