<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn = new mysqli("sql302.infinityfree.com", "if0_39040743", "SHINee2003", "if0_39040743_campus_lostfound");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$item_id = $_POST['item_id'] ?? '';
$claim_reason = $_POST['claim_reason'] ?? '';
$source = $_POST['source'] ?? '';

if (empty($item_id) || empty($claim_reason) || empty($source)) {
    echo "Missing data. Please go back and fill in all fields.";
    exit;
}

$item_id = intval($item_id);
$claim_reason = $conn->real_escape_string($claim_reason);
$source = $conn->real_escape_string($source); // 'lost_items' or 'found_items'

$sql = "INSERT INTO claims (item_id, claim_reason, user_id, claim_date) VALUES (?, ?, NULL, NOW())";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Query error: " . $conn->error);
}

$stmt->bind_param("is", $item_id, $claim_reason);

if ($stmt->execute()) {
    echo "<h3>✅ Your claim has been submitted for review.</h3>";
    echo "<p><a href='homepage.html'>Back to homepage</a></p>";
} else {
    echo "❌ Failed to submit claim: " . $conn->error;
}

$stmt->close();
$conn->close();
?>
