<?php
// Turn on error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

$host = "sql213.infinityfree.com";     // e.g., sql312.epizy.com (check in your InfinityFree Control Panel)
$user = "if0_39106768";        // your actual database username
$pass = "Gktc7112003";  // your database password
$dbname = "if0_39106768_seow_contact"; // your actual database name

// Connect to the database
$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get and sanitize POST data
$name = htmlspecialchars($_POST['name']);
$matric = htmlspecialchars($_POST['matric']);
$contact = htmlspecialchars($_POST['contact']);
$faculty = htmlspecialchars($_POST['faculty']);
$email = htmlspecialchars($_POST['email']);
$message = htmlspecialchars($_POST['message']);

// Insert into database
$sql = "INSERT INTO contact_form (name, matric, contact, faculty, email, message) VALUES (?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssss", $name, $matric, $contact, $faculty, $email, $message);

if ($stmt->execute()) {
    echo "✅ Your message has been submitted successfully!";
} else {
    echo "❌ Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
