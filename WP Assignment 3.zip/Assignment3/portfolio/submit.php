<?php

$host = "sql213.infinityfree.com";       
$user = "if0_39106768";         
$pass = "Gktc7112003";         
$dbname = "if0_39106768_seow_contact"; 

// Create connection
$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    die("❌ Connection failed: " . $conn->connect_error);
}

// Sanitize and get form input
$name    = htmlspecialchars($_POST['name']);
$matric  = htmlspecialchars($_POST['matric']);
$contact = htmlspecialchars($_POST['contact']);
$faculty = htmlspecialchars($_POST['faculty']);
$email   = htmlspecialchars($_POST['email']);
$message = htmlspecialchars($_POST['message']);

// Prepare SQL insert
$sql = "INSERT INTO contact_form (name, matric, contact, faculty, email, message)
        VALUES (?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssss", $name, $matric, $contact, $faculty, $email, $message);

// Execute and respond
if ($stmt->execute()) {
    echo "<h2>✅ Thank you! Your message has been saved.</h2>";
} else {
    echo "❌ Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
