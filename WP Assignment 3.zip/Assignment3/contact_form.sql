-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql213.byetcluster.com
-- Generation Time: May 29, 2025 at 01:13 PM
-- Server version: 10.6.19-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_39106768_seow_contact`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact_form`
--

CREATE TABLE `contact_form` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `matric` varchar(20) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `faculty` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `contact_form`
--

INSERT INTO `contact_form` (`id`, `name`, `matric`, `contact`, `faculty`, `email`, `message`, `submitted_at`) VALUES
(1, 'seow', 'A23CS0177', '0126844311', 'Faculty of Computing', 'seowyenzhi@gmail.com', 'Hi, have you done your Web Programming Assignment 3?\r\n', '2025-05-29 03:56:25'),
(2, 'Seow Yen Zhi', 'A23CS0177', '0126844311', 'Faculty of Computing', 'seowyenzhi@gmail.com', 'Hi, how is your progress for the Web Programming Assignment 3?', '2025-05-29 04:00:55'),
(3, 'Seow', 'A23CS0177', '0126844311', 'Faculty of Computing', 'seowyenzhi@gmail.com', 'Web Programming is fun!', '2025-05-29 04:06:29'),
(4, 'Seow', 'A23CS0177', '0126844311', 'Faculty of Computing', 'seowyenzhi@gmail.com', 'Hello, how are you recently?', '2025-05-29 17:04:54'),
(5, 'seow', 'A23CS0177', '0126844311', 'Faculty of Computing', 'seowyenzhi@gmail.com', 'Web Programming is fun!', '2025-05-29 17:06:09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact_form`
--
ALTER TABLE `contact_form`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact_form`
--
ALTER TABLE `contact_form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
