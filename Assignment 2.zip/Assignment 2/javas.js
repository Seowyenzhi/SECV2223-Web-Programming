// Greet the user based on the time of day
function greetUser() {
  const now = new Date();
  const hour = now.getHours();
  let greeting = "Welcome!";

  if (hour < 12) {
    greeting = "Good morning! ";
  } else if (hour < 18) {
    greeting = "Good afternoon! ";
  } else {
    greeting = "Good evening! ";
  }

  alert(greeting + "Thank you for visiting. Have a nice day");
}

// Show fun facts about the user
function showFunFacts() {
  const facts = [
    "🌱 I love nature",
    "🎧 I listen to music while studying",
    "📚 I enjoy watching horror movies",
    "🚴 I go cycling during weekends",
  ];

  for (let i = 0; i < facts.length; i++) {
    const next = confirm(facts[i] + "\n\nWant to see the next fun fact?");
    if (!next) break;
  }

  alert("Thanks for learning more about me!");
}


// Toggle the visibility of the project message
function toggleProjectMessage() {
  const msg = document.getElementById("message");
  if (msg.style.display === "none") {
    msg.style.display = "block";
  } else {
    msg.style.display = "none";
  }
}

